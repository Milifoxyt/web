/**
 * milifo 博客 —— EdgeOne Pages Functions 版后端
 * 路径：functions/api/[[default]].js  →  匹配 /api/*
 *
 * 存储：EdgeOne Pages KV（在控制台绑定，变量名建议 BLOG_KV）
 * 运行环境：V8 isolate（Web Crypto / fetch / Request / Response）
 */

const COOKIE = 'mf_sess';
const SESSION_DAYS = 30;
const MAX_POSTS = 500;

/* ------------------------------ 工具 ------------------------------ */

const enc = new TextEncoder();

function json(obj, status = 200, extra = {}) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      ...extra
    }
  });
}

const bad = (msg, status = 400) => json({ ok: false, error: msg }, status);

function kvOf(env) {
  const cand = [
    env && env.BLOG_KV,
    env && env.KV,
    typeof BLOG_KV !== 'undefined' ? BLOG_KV : null,
    typeof my_kv !== 'undefined' ? my_kv : null
  ];
  for (const c of cand) if (c && typeof c.get === 'function') return c;
  throw new Error('KV 没有绑定：请在 Pages 控制台绑定 KV，变量名 BLOG_KV');
}

async function jget(kv, key, fallback = null) {
  const raw = await kv.get(key);
  if (raw === null || raw === undefined || raw === '') return fallback;
  try { return JSON.parse(raw); } catch { return fallback; }
}

const jset = (kv, key, val) => kv.put(key, JSON.stringify(val));

const rnd = (n) => {
  const b = new Uint8Array(n);
  crypto.getRandomValues(b);
  return Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
};

const b64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)));

async function pbkdf2(password, saltB64, iterations = 120000) {
  const salt = Uint8Array.from(atob(saltB64), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' }, key, 256
  );
  return b64(bits);
}

async function hashPassword(password) {
  const salt = rnd(16);
  const saltB64 = btoa(String.fromCharCode(...Uint8Array.from(salt.match(/../g).map((h) => parseInt(h, 16)))));
  const hash = await pbkdf2(password, saltB64);
  return `pbkdf2$${saltB64}$${hash}`;
}

async function checkPassword(password, stored) {
  const [algo, saltB64, hash] = String(stored).split('$');
  if (algo !== 'pbkdf2' || !saltB64 || !hash) return false;
  const test = await pbkdf2(password, saltB64);
  if (test.length !== hash.length) return false;
  let diff = 0;
  for (let i = 0; i < test.length; i++) diff |= test.charCodeAt(i) ^ hash.charCodeAt(i);
  return diff === 0;
}

function cookies(req) {
  const raw = req.headers.get('cookie') || '';
  const out = {};
  raw.split(';').forEach((part) => {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  });
  return out;
}

const setCookie = (token, maxAge) =>
  `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}`;

function originOk(req, url) {
  const o = req.headers.get('origin');
  if (!o) return true;
  try { return new URL(o).host === url.host; } catch { return false; }
}

async function body(req) {
  const ct = req.headers.get('content-type') || '';
  if (ct.includes('application/json')) {
    try { return await req.json(); } catch { return {}; }
  }
  const text = await req.text();
  const out = {};
  new URLSearchParams(text).forEach((v, k) => { out[k] = v; });
  return out;
}

/* ------------------------------ 数据 ------------------------------ */

async function currentUser(req, kv) {
  const token = cookies(req)[COOKIE];
  if (!token) return null;
  const sess = await jget(kv, `sess:${token}`);
  if (!sess || sess.exp < Date.now()) return null;
  const user = await jget(kv, `user:${sess.email}`);
  return user ? { ...user, token } : null;
}

async function createSession(kv, email) {
  const token = rnd(32);
  await jset(kv, `sess:${token}`, { email, exp: Date.now() + SESSION_DAYS * 864e5 });
  return token;
}

const publicUser = (u) => u && {
  id: u.id, email: u.email, name: u.name, role: u.role, createdAt: u.createdAt
};

async function allPosts(kv) {
  const ids = await jget(kv, 'posts:index', []);
  if (!ids.length) return [];
  const rows = await Promise.all(ids.map((id) => jget(kv, `post:${id}`)));
  return rows.filter(Boolean);
}

const visible = (post, user) =>
  post.status === 'published' || (user && (user.role === 'admin' || user.email === post.authorEmail));

/* ------------------------------ 初始化 ------------------------------ */

const DEMO = [
  {
    title: '在南昌路的二楼读完《城市与狗》',
    excerpt: '十一月的上海开始起雾。我在南昌路一家旧书店的二楼，把《城市与狗》的最后三十页读完了。',
    body: '十一月的上海开始起雾。我在南昌路一家旧书店的二楼，把《城市与狗》的最后三十页读完了。\n\n## 为什么是这张桌子\n\n靠窗第二张，椅背有点松，但正对着梧桐。下午四点的光会斜着落到书页上，字会变淡，得把书往左挪一点。\n\n> 一本书读到最后一页的时候，记住的往往不是情节，而是当时的光线、声音，和椅子硬不硬。\n\n书店的猫叫「报纸」，会在你翻页的时候抬头看你一眼，然后继续睡。',
    kind: 'original'
  },
  {
    title: '把阅读当成一种坐标',
    excerpt: '我记不住读过的每一本书，但记得读它的那个下午。',
    body: '我记不住读过的每一本书，但记得读它的那个下午。\n\n书的内容会被忘掉，但读它的那个下午——光、声音、椅子硬不硬——往往记得很清楚。\n\n所以这个站只记两件事：读了什么，以及在哪儿读的。',
    kind: 'original'
  },
  {
    title: '关于「读不完」这件事',
    excerpt: '有些书不是用来读完的，是用来放在床头的。',
    body: '有些书不是用来读完的，是用来放在床头的。\n\n读了一半停下来，不代表放弃。它在那儿，每天看一眼，也许某天就接着读了。',
    kind: 'original'
  }
];

async function ensureSeed(kv, env) {
  const done = await jget(kv, 'meta:seeded');
  if (done) return;

  const email = (env && env.ADMIN_EMAIL) || 'hi@milifo.com';
  const password = (env && env.ADMIN_PASSWORD) || 'milifo-admin-2026';
  const now = Date.now();

  const admin = {
    id: 1,
    email: email.toLowerCase(),
    name: (env && env.ADMIN_NAME) || 'milifo',
    pass: await hashPassword(password),
    role: 'admin',
    createdAt: now
  };
  await jset(kv, `user:${admin.email}`, admin);
  await jset(kv, 'users:index', [admin.email]);
  await jset(kv, 'seq:user', 1);

  const ids = [];
  let pid = 0;
  for (const d of DEMO) {
    pid += 1;
    const post = {
      id: pid,
      title: d.title,
      excerpt: d.excerpt,
      body: d.body,
      cover: '',
      kind: 'original',
      status: 'published',
      authorEmail: admin.email,
      authorName: admin.name || 'milifo',
      createdAt: now - pid * 3600e3,
      updatedAt: now - pid * 3600e3
    };
    await jset(kv, `post:${pid}`, post);
    ids.unshift(pid);
  }
  await jset(kv, 'posts:index', ids);
  await jset(kv, 'seq:post', pid);
  await jset(kv, 'meta:seeded', { at: now });
}

/* ------------------------------ Blob（图片） ------------------------------ */

const IMG_MAX = 5 * 1024 * 1024;

const MIME = {
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  png: 'image/png',
  webp: 'image/webp',
  gif: 'image/gif'
};

let _blobStore = null;
let _blobTried = false;

/** 懒加载 Blob SDK：没装/没绑定时返回 null，只影响上传，不影响其它接口 */
async function blobStore(env) {
  if (_blobTried) return _blobStore;
  _blobTried = true;
  try {
    const mod = await import('@edgeone/pages-blob');
    const name = (env && (env.BLOB_STORE || env.BLOB_STORE_NAME)) || 'BLOG_BLOB';
    _blobStore = mod.getStore(name);
  } catch (e) {
    _blobStore = null;
  }
  return _blobStore;
}

function sniffImage(bytes) {
  const b = new Uint8Array(bytes.slice(0, 12));
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpg';
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return 'png';
  if (b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46) return 'gif';
  if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 &&
      b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return 'webp';
  return null;
}

/**
 * 把 Blob 包成 KV 的形状（get / put / delete），
 * 这样上面所有 jget / jset 逻辑一行都不用改。
 */
function blobAsKV(store) {
  return {
    async get(key) {
      const v = await store.get(key, { type: 'text', consistency: 'strong' });
      return v === null || v === undefined ? null : v;
    },
    async put(key, value) {
      await store.set(key, String(value));
    },
    async delete(key) {
      await store.delete(key);
    }
  };
}

/** 默认全部数据放 Blob；设 STORE=kv 可以退回 KV */
async function storeOf(env) {
  const mode = String((env && env.STORE) || 'blob').toLowerCase();
  if (mode === 'kv') return kvOf(env);
  const s = await blobStore(env);
  if (!s) throw new Error('数据存储需要 Blob：请在控制台绑定 Blob 存储（变量名 BLOG_BLOB）');
  return blobAsKV(s);
}

/* ------------------------------ 路由 ------------------------------ */

export async function onRequest(ctx) {
  const { request, env } = ctx;
  const url = new URL(request.url);
  const path = url.pathname.replace(/\/+$/, '');
  const method = request.method.toUpperCase();

  let kv;
  try {
    kv = await storeOf(env);
  } catch (e) {
    return json({ ok: false, error: e.message, needsBlob: true }, 500);
  }

  try {
    await ensureSeed(kv, env);
  } catch (e) {
    return json({ ok: false, error: 'KV 初始化失败：' + (e.message || e) }, 500);
  }

  const user = await currentUser(request, kv);

  if (method === 'POST' && !originOk(request, url)) {
    return bad('跨站请求被拒绝', 403);
  }

  try {
    /* ---------- 图片（Blob） ---------- */
    if (path.startsWith('/api/img/')) {
      if (method !== 'GET') return bad('只支持 GET', 405);
      const store = await blobStore(env);
      if (!store) return bad('Blob 没有配置', 501);
      const key = decodeURIComponent(path.slice('/api/img/'.length));
      if (!key || key.includes('..')) return bad('路径不对', 400);
      const buf = await store.get(key, { type: 'arrayBuffer' });
      if (!buf) return bad('图片不存在', 404);
      const ext = (key.split('.').pop() || 'jpg').toLowerCase();
      return new Response(buf, {
        status: 200,
        headers: {
          'content-type': MIME[ext] || 'application/octet-stream',
          'cache-control': 'public, max-age=31536000, immutable'
        }
      });
    }

    if (path === '/api/upload') {
      if (method !== 'POST') return bad('只支持 POST', 405);
      if (!user) return bad('请先登录', 401);
      const store = await blobStore(env);
      if (!store) return bad('图片上传还没配置：需要绑定 Blob 存储', 501);

      const bytes = await request.arrayBuffer();
      if (!bytes || bytes.byteLength === 0) return bad('没有收到文件');
      if (bytes.byteLength > IMG_MAX) return bad('图片最大 5MB');

      const ext = sniffImage(bytes);
      if (!ext) return bad('只支持 jpg / png / webp / gif');

      const key = `img/${Date.now()}-${rnd(4)}.${ext}`;
      await store.set(key, bytes);
      return json({ ok: true, url: `/api/img/${key}`, key });
    }

    switch (path) {
      /* ---------- 会话 ---------- */
      case '/api/session':
        return json({ ok: true, user: publicUser(user) });

      case '/api/login': {
        if (method !== 'POST') return bad('只支持 POST', 405);
        const b = await body(request);
        const email = String(b.email || '').trim().toLowerCase();
        const u = await jget(kv, `user:${email}`);
        if (!u || !(await checkPassword(String(b.password || ''), u.pass))) {
          return json({ ok: false, error: '邮箱或密码不对' }, 401);
        }
        const token = await createSession(kv, u.email);
        return json({ ok: true, user: publicUser(u) }, 200, { 'set-cookie': setCookie(token, SESSION_DAYS * 86400) });
      }

      case '/api/register': {
        if (method !== 'POST') return bad('只支持 POST', 405);
        const b = await body(request);
        const email = String(b.email || '').trim().toLowerCase();
        const name = String(b.name || '').trim();
        const password = String(b.password || '');
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return bad('邮箱格式不对');
        if (password.length < 8) return bad('密码至少 8 位');
        if (await jget(kv, `user:${email}`)) return bad('这个邮箱已经注册过了', 409);

        const seq = (await jget(kv, 'seq:user', 0)) + 1;
        const u = {
          id: seq,
          email,
          name: name || email.split('@')[0],
          pass: await hashPassword(password),
          role: 'member',
          createdAt: Date.now()
        };
        await jset(kv, `user:${email}`, u);
        const idx = await jget(kv, 'users:index', []);
        idx.push(email);
        await jset(kv, 'users:index', idx);
        await jset(kv, 'seq:user', seq);

        const token = await createSession(kv, email);
        return json({ ok: true, user: publicUser(u) }, 200, { 'set-cookie': setCookie(token, SESSION_DAYS * 86400) });
      }

      case '/api/logout': {
        const token = cookies(request)[COOKIE];
        if (token) await kv.delete(`sess:${token}`);
        return json({ ok: true }, 200, { 'set-cookie': setCookie('', 0) });
      }

      /* ---------- 文章 ---------- */
      case '/api/posts': {
        const kind = url.searchParams.get('kind') || 'all';
        const posts = (await allPosts(kv))
          .filter((p) => p.status === 'published')
          .filter((p) => kind === 'all' || p.kind === kind)
          .sort((a, b) => b.createdAt - a.createdAt)
          .map((p) => ({
            id: p.id, title: p.title, excerpt: p.excerpt, cover: p.cover,
            kind: p.kind, status: p.status, authorName: p.authorName,
            createdAt: p.createdAt
          }));
        return json({ ok: true, posts });
      }

      case '/api/post': {
        const id = Number(url.searchParams.get('id'));
        const p = await jget(kv, `post:${id}`);
        if (!p) return bad('文章不存在', 404);
        if (!visible(p, user)) return bad('文章不存在', 404);
        const cmts = await jget(kv, `cmt:${id}`, []);
        return json({ ok: true, post: p, comments: cmts, user: publicUser(user) });
      }

      case '/api/post/save': {
        if (method !== 'POST') return bad('只支持 POST', 405);
        if (!user) return bad('请先登录', 401);
        const b = await body(request);
        const title = String(b.title || '').trim();
        const text = String(b.body || '').trim();
        if (title.length < 2) return bad('标题太短');
        if (text.length < 5) return bad('正文太短');

        const isAdmin = user.role === 'admin';
        const id = Number(b.id) || 0;

        if (id) {
          const old = await jget(kv, `post:${id}`);
          if (!old) return bad('文章不存在', 404);
          if (!isAdmin && old.authorEmail !== user.email) return bad('不能改别人的文章', 403);
          const next = {
            ...old, title,
            excerpt: String(b.excerpt || '').trim() || text.slice(0, 60),
            body: text,
            cover: String(b.cover || old.cover || ''),
            updatedAt: Date.now()
          };
          if (isAdmin && b.status) next.status = b.status;
          await jset(kv, `post:${id}`, next);
          return json({ ok: true, post: next });
        }

        const seq = (await jget(kv, 'seq:post', 0)) + 1;
        const post = {
          id: seq,
          title,
          excerpt: String(b.excerpt || '').trim() || text.slice(0, 60),
          body: text,
          cover: String(b.cover || ''),
          kind: isAdmin ? 'original' : 'community',
          status: isAdmin ? (b.status || 'published') : 'pending',
          authorEmail: user.email,
          authorName: user.name || user.email.split('@')[0],
          createdAt: Date.now(),
          updatedAt: Date.now()
        };
        await jset(kv, `post:${seq}`, post);
        const idx = await jget(kv, 'posts:index', []);
        idx.unshift(seq);
        await jset(kv, 'posts:index', idx.slice(0, MAX_POSTS));
        await jset(kv, 'seq:post', seq);
        return json({ ok: true, post });
      }

      case '/api/post/delete': {
        if (method !== 'POST') return bad('只支持 POST', 405);
        if (!user) return bad('请先登录', 401);
        const b = await body(request);
        const id = Number(b.id);
        const p = await jget(kv, `post:${id}`);
        if (!p) return bad('文章不存在', 404);
        if (user.role !== 'admin' && p.authorEmail !== user.email) return bad('没有权限', 403);
        await kv.delete(`post:${id}`);
        await kv.delete(`cmt:${id}`);
        const idx = (await jget(kv, 'posts:index', [])).filter((x) => x !== id);
        await jset(kv, 'posts:index', idx);
        return json({ ok: true });
      }

      case '/api/moderate': {
        if (method !== 'POST') return bad('只支持 POST', 405);
        if (!user || user.role !== 'admin') return bad('需要站长权限', 403);
        const b = await body(request);
        const id = Number(b.id);
        const action = String(b.action || '');
        const p = await jget(kv, `post:${id}`);
        if (!p) return bad('文章不存在', 404);
        if (action === 'approve') {
          p.status = 'published';
          p.updatedAt = Date.now();
          await jset(kv, `post:${id}`, p);
        } else if (action === 'reject') {
          await kv.delete(`post:${id}`);
          const idx = (await jget(kv, 'posts:index', [])).filter((x) => x !== id);
          await jset(kv, 'posts:index', idx);
        } else {
          return bad('不认识的操作');
        }
        return json({ ok: true });
      }

      /* ---------- 留言 ---------- */
      case '/api/comment': {
        if (method !== 'POST') return bad('只支持 POST', 405);
        if (!user) return bad('请先登录再留言', 401);
        const b = await body(request);
        const pid = Number(b.post);
        const text = String(b.body || '').trim();
        if (text.length < 1) return bad('写点什么再发');
        if (text.length > 2000) return bad('太长了，2000 字以内');
        const p = await jget(kv, `post:${pid}`);
        if (!p || p.status !== 'published') return bad('文章不存在', 404);

        const cmts = await jget(kv, `cmt:${pid}`, []);
        const c = {
          id: cmts.length ? Math.max(...cmts.map((x) => x.id)) + 1 : 1,
          name: user.name || user.email.split('@')[0],
          email: user.email,
          body: text,
          createdAt: Date.now()
        };
        cmts.push(c);
        await jset(kv, `cmt:${pid}`, cmts);
        return json({ ok: true, comment: c });
      }

      /* ---------- 后台 ---------- */
      case '/api/admin/queue': {
        if (!user || user.role !== 'admin') return bad('需要站长权限', 403);
        const posts = (await allPosts(kv))
          .sort((a, b) => b.createdAt - a.createdAt)
          .map((p) => ({
            id: p.id, title: p.title, excerpt: p.excerpt, kind: p.kind,
            status: p.status, authorName: p.authorName, createdAt: p.createdAt
          }));
        return json({
          ok: true,
          pending: posts.filter((p) => p.status === 'pending'),
          all: posts
        });
      }

      case '/api/health': {
        const store = await blobStore(env);
        const mode = String((env && env.STORE) || 'blob').toLowerCase() === 'kv' ? 'kv' : 'blob';
        return json({
          ok: true,
          store: mode,
          kv: mode === 'kv',
          blob: !!store,
          user: publicUser(user)
        });
      }

      default:
        return bad('没有这个接口：' + path, 404);
    }
  } catch (e) {
    return json({ ok: false, error: String(e && e.message || e) }, 500);
  }
}
